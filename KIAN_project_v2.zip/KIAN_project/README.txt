KIAN — Starter Package
======================

Files:
- index.html: Persian RTL landing page (no payment collection)
- KIAN.sol: minimal fixed-supply ERC-20 prototype using OpenZeppelin Contracts
- DEPLOYMENT_AND_SAFETY.txt: next steps and safety checklist

This package is NOT deployed. No real token sale or market exists from these files.
The Solidity contract imports OpenZeppelin Contracts, so compiling it requires that
dependency in a Solidity development environment.

Do not deploy this prototype to mainnet or offer it for public purchase before:
1. Independent smart-contract security review.
2. Legal/regulatory review in the jurisdictions where the project is operated/offered.
3. Written tokenomics and treasury/charity rules.
4. Clear disclosures, privacy/consumer-protection compliance, and tax advice.
5. Testing on a test network and verification of the source code.

A token contract does not itself create demand, exchange liquidity, or a price.
No one can guarantee buyers or a specific amount of sales in an hour.
Never create fake volume, mislead buyers, promise guaranteed returns, or use
owner-controlled mechanisms to manipulate price. Never share seed phrases/private keys.
