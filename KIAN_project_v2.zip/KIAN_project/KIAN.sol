// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * KIAN educational prototype.
 * Fixed-supply ERC-20 token. No owner minting, no trading controls, no tax,
 * no price promises, and no built-in liquidity manipulation.
 *
 * IMPORTANT:
 * - This is an unreviewed prototype, not audited production code.
 * - Do not deploy or sell to the public before independent security/legal review.
 * - This contract does not create a market, exchange listing, or guaranteed buyers.
 */
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract KIAN is ERC20 {
    constructor(uint256 initialSupply) ERC20("KIAN", "KIAN") {
        require(initialSupply > 0, "Supply must be positive");
        _mint(msg.sender, initialSupply);
    }
}
